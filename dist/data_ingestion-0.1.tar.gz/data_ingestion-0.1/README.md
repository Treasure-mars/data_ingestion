# mypackage
This is an example

## Building this package locally
`python setup.py sdist`

## Installing this package from github
`pip install git+https://github.com/Treasure-mars/mypackage.git`

## Updating this package from github
`pip install --upgrade git+https://github.com/Treasure-mars/mypackage.git`